import argparse
from scapy.all import rdpcap, IP, TCP
from collections import defaultdict
from datetime import datetime

def analyze_pcap(file_path):
    packets = rdpcap(file_path)
    outbound_connections = defaultdict(int)
    timestamps = []

    for pkt in packets:
        if IP in pkt and TCP in pkt:
            src = pkt[IP].src
            dst = pkt[IP].dst
            dport = pkt[TCP].dport
            time = pkt.time
            timestamps.append(time)

            if src.startswith('192.168.') or src.startswith('10.'):
                outbound_connections[(dst, dport)] += 1

    high_risk_events = []
    if len(outbound_connections) > 20:
        high_risk_events.append(f"[!] Suspicious burst: {len(outbound_connections)} outbound connections")

    risky_ports = [4444, 3389, 23]
    for (dst, port), count in outbound_connections.items():
        if port in risky_ports:
            high_risk_events.append(f"[!] Potential C2 communication to {dst}:{port}")

    if not high_risk_events:
        print("[+] No ransomware behavior detected.")
    else:
        for event in high_risk_events:
            print(event)
        print(f"[+] Analysis complete: {len(high_risk_events)} high-risk events flagged.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze pcap for ransomware-like traffic patterns")
    parser.add_argument("--pcap", required=True, help="Path to the .pcap file")
    args = parser.parse_args()

    analyze_pcap(args.pcap)
